# load binary file
