Suite2p processes 2p calcium imaging data from raw tifs to extracted fluorescence traces and spike times. 
Copyright (C) 2018  Howard Hughes Medical Institute Janelia Research Campus
